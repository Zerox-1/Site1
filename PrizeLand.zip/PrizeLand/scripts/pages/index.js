function FillCategoryPreviewTabs(tabInputId, tabContentId, sex) {
    let tabInput = document.getElementById(tabInputId);
    let tabContent = document.getElementById(tabContentId);

    let products = productsDatabase.data.filter((el) => el.type === tabInput.value);
    products = products.filter((el) => el.sex === sex);

    products.forEach(product => {
        let productCard = document.createElement('a');
        productCard.href = `product.html?id=`+product.id;
        productCard.style.display = 'flex';
        productCard.style.flexDirection = 'column';
        productCard.style.alignItems = 'center';
        productCard.style.cursor = 'pointer';
        productCard.style.border = '1px solid';
        productCard.style.borderRadius = '8px';
        productCard.style.margin = '5px';


        let productImg = document.createElement('img');
        productImg.src = product.imagePath;
        productImg.style.width = '250px';
        productImg.style.borderRadius = '8px'

        let productName = document.createElement('h3');
        let productPrice = document.createElement('h3');

        productName.innerText = product.name;
        productPrice.innerText = product.price + " ₽";

        productCard.appendChild(productImg);
        productCard.appendChild(productName);
        productCard.appendChild(productPrice);

        tabContent.appendChild(productCard);
    })

}

// initialize products
FillCategoryPreviewTabs('tab-btn-1-women', 'content-1-women', 'Женский');
FillCategoryPreviewTabs('tab-btn-2-women', 'content-2-women', 'Женский');
FillCategoryPreviewTabs('tab-btn-3-women', 'content-3-women', 'Женский');
FillCategoryPreviewTabs('tab-btn-4-women', 'content-4-women', 'Женский');


FillCategoryPreviewTabs('tab-btn-1-men', 'content-1-men', 'Мужской');
FillCategoryPreviewTabs('tab-btn-2-men', 'content-2-men', 'Мужской');
FillCategoryPreviewTabs('tab-btn-3-men', 'content-3-men', 'Мужской');
FillCategoryPreviewTabs('tab-btn-4-men', 'content-4-men', 'Мужской');