const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
});

let filteredData = [];

let types = [''];
let subtypes = [''];
let sex = [];
let brands = [''];

filteredData = [...productsDatabase.data];

productsDatabase.data.forEach((el) => {
    if (!types.includes(el.type)) {
        types.push(el.type);
    }
    if (!subtypes.includes(el.subType)) {
        subtypes.push(el.subType);
    }
    if (!sex.includes(el.sex)) {
        sex.push(el.sex);
    }
    if (!brands.includes(el.brand)) {
        brands.push(el.brand);
    }
})

let sexSelect = document.getElementById('product-sex-select');
let typeSelect = document.getElementById('product-type-select');
let subTypeSelect = document.getElementById('product-subType-select');
let brandSelect = document.getElementById('product-brand-select');

let productsContainer = document.getElementById('products-container');

types.forEach(el => {
    let option = document.createElement('option');
    option.innerText = el;
    option.value = el;
    typeSelect.appendChild(option);
})

subtypes.forEach(el => {
    let option = document.createElement('option');
    option.innerText = el;
    option.value = el;
    subTypeSelect.appendChild(option);
})


brands.forEach(el => {
    let option = document.createElement('option');
    option.innerText = el;
    option.value = el;
    brandSelect.appendChild(option);
})

function filterBySex(sex) {
    if(sex === null || sex === ""){
        return;
    }
    filteredData = filteredData.filter(el => el.sex === sex);
}
function filterByType(type) {
    if(type === null || type === ""){
        return;
    }
    filteredData = filteredData.filter(el => el.type === type);
}


function filterBySubType(subType) {
    if(subType === null || subType === ""){
        return;
    }
    filteredData = filteredData.filter(el => el.subType === subType);
}

function filterByBrand(brand) {
    if(brand === null || brand === ""){
        return;
    }
    filteredData = filteredData.filter(el => el.brand === brand);
}

if(params.sex !== undefined){
    filterBySex(params.sex);
}
drawItems();
function drawItems() {
    productsContainer.innerHTML = null;
    filteredData.forEach(product => {
        let productCard = document.createElement('a');
        productCard.href = `product.html?id=` + product.id;
        productCard.style.display = 'flex';
        productCard.style.flexDirection = 'row';
        productCard.style.alignItems = 'center';
        productCard.style.cursor = 'pointer';
        productCard.style.border = '1px solid';
        productCard.style.borderRadius = '8px';
        productCard.style.justifyContent = 'space-between';
        productCard.style.marginBottom = '10px';

        let productImg = document.createElement('img');
        productImg.src = product.imagePath;
        productImg.style.width = '200px';
        productImg.style.borderRadius = '8px'

        let priceBlock = document.createElement('div');
        priceBlock.style.display = 'flex';
        priceBlock.style.marginRight = '100px';


        let productDescriptionContainer = document.createElement('div');
        productDescriptionContainer.style.display = 'flex';
        productDescriptionContainer.style.flexDirection = 'column';
        productDescriptionContainer.style.alignItems = 'center';
        productDescriptionContainer.style.padding = '10px';

        let productName = document.createElement('h3');
        productName.innerText = product.name;

        let productDescription = document.createElement('span');
        productDescription.innerText = product.description;

        productDescriptionContainer.appendChild(productName);
        productDescriptionContainer.appendChild(productDescription);

        let productPrice = document.createElement('h3');

        productPrice.innerText = product.price + " ₽";

        priceBlock.appendChild(productPrice);

        productCard.appendChild(productImg);
        productCard.appendChild(productDescriptionContainer);
        productCard.appendChild(priceBlock);
        productsContainer.appendChild(productCard);
    })
}

function applyFiltersButtonClicked(){
    filteredData = [...productsDatabase.data];
    filterBySex(sexSelect.selectedOptions[0].value)
    filterByType(typeSelect.selectedOptions[0].value);
    filterBySubType(subTypeSelect.selectedOptions[0].value);
    filterByBrand(brandSelect.selectedOptions[0].value);
    drawItems()
}