const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
});

let productId = params.id;
let product = productsDatabase.data.find((el) => el.id == productId);

if (product === undefined) {
    document.getElementById('product-name').innerText = "Продукт не найден";
} else {
    document.getElementById('product-name').innerText = product.name;
    document.getElementById('product-type').innerText = product.type;
    document.getElementById('product-subtype').innerText = product.subType;
    document.getElementById('product-sex').innerText = product.sex;
    document.getElementById('product-brand').innerText = product.brand;
    document.getElementById('product-description').innerText = product.description;
    document.getElementById('product-price').innerText = product.price + ' ₽';
    document.getElementById('product-img').src = product.imagePath;
}


function addProductToCart(){
    if(Authentication.GetCurrentUser() === null){
        alert("Войдите в аккаунт для добавления в корзину");
        return;
    }

    let cartItem = new CartItemEntity();
    cartItem.productId = productId;
    cartItem.userId = Authentication.GetCurrentUser().id;

    cartItemsDatabase.UpdateItem(cartItem);

}