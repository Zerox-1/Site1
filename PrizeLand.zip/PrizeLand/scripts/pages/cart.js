let currentUser = Authentication.GetCurrentUser();
if (currentUser === null) {
    window.location.href = 'index.html';
    alert("Для просмотра корзины необходимо войти в аккаунт");
    throw new Error('Пользователь не авторизован');
}
let cart = [];

cart = cartItemsDatabase.data.filter(el => el.userId === currentUser.id);

let cartItemsContainer = document.getElementById('shopping-cart');

drawCart();
function drawCart() {
    cart.forEach(el => {
        let product = productsDatabase.GetById(parseInt(el.productId));

        let cartItem = document.createElement('div');
        cartItem.className = "item";

        let img = document.createElement('img');
        img.src = product.imagePath;
        img.className = "image";

        let description = document.createElement('div');
        description.className = "description";

        let productName = document.createElement('span');
        productName.innerText = product.name;

        description.appendChild(productName);

        let price = document.createElement('div');
        price.className = 'total-price';
        price.innerText = product.price + ' ₽';

        let removeButton = document.createElement('button');
        removeButton.className = 'price-button';
        removeButton.onclick=removeItemFromCart;

        removeButton.value = el.id;

        let removeIcon = document.createElement('span');
        removeIcon.innerText = 'delete'
        removeIcon.className = 'material-symbols-outlined';
        removeButton.appendChild(removeIcon)

        cartItem.appendChild(img);
        cartItem.appendChild(description);
        cartItem.appendChild(price);
        cartItem.appendChild(removeButton);
        cartItemsContainer.appendChild(cartItem);
    })
}

function removeItemFromCart(sender) {
    let button = sender.target;
    let item = cartItemsDatabase.GetById(parseInt(button.value));
    cartItemsDatabase.RemoveItem(item);
    window.location.href = 'cart.html';
}