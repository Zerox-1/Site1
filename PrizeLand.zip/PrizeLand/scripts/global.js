// common page scripts start
let signInForm = document.getElementById('sign-in-form');
let signUpForm = document.getElementById('sign-up-form');

function SwitchAuthForm() {


    if (signInForm.style.visibility === 'visible') {
        signInForm.style.visibility = 'collapse';
        signInForm.style.display = 'none';

        signUpForm.style.visibility = 'visible';
        signUpForm.style.display = 'flex';
    } else {
        signUpForm.style.visibility = 'collapse';
        signUpForm.style.display = 'none';

        signInForm.style.visibility = 'visible';
        signInForm.style.display = 'flex';
    }
}

function ShowAuthOverlay() {
    switchElementVisibility('authentication-overlay-container');
    SwitchAuthForm();
}

function switchElementVisibility(elementId, defaultDisplayMode = 'flex') {
    let element = document.getElementById(elementId);
    element.style.visibility = element.style.visibility === 'visible' ? 'collapse' : 'visible';
    element.style.display = element.style.display === defaultDisplayMode ? 'none' : defaultDisplayMode;

}


function SignInButtonClicked() {
    let signInLoginInput = document.getElementById('login-sign-in-input');
    let signInPasswordInput = document.getElementById('password-sign-in-input');

    let signInResult = Authentication.SignIn(signInLoginInput.value, signInPasswordInput.value);

    if (!signInResult) {
        alert('Некорректный логин или пароль');
        return;
    }
    window.location.href = 'index.html'
}

function SignUpButtonClicked() {
    let signUpLogin = document.getElementById('login-sign-up-input').value;
    let signUpPassword = document.getElementById('password-sign-up-input').value;
    let signUpPasswordRepeat = document.getElementById('password-repeat-sign-up-input').value;

    if (signUpPassword !== signUpPasswordRepeat) {
        alert('Пароли должны быть одинаковые');
        return;
    }

    let userEntity = new UserEntity();
    if (!userEntity.SetLogin(signUpLogin)) {
        alert('Некорректный логин');
        return;
    }
    if (!userEntity.SetPassword(signUpPassword)) {
        alert('Некорректный пароль');
        return;
    }

    if (!Authentication.SignUp(userEntity)) {
        alert('Скорее всего такой пользователь уже существует');
        return;
    }
    alert(`Пользователь ${userEntity.login} создан`);
}


// common page scripts end


let user1 = new UserEntity();
user1.SetLogin("Regina");
user1.SetPassword("1235Qwerty");

let user2 = new UserEntity();
user2.SetLogin("Nail");
user2.SetPassword("Nail12345");




var usersDatabase = new UsersDatabase('UsersDatabase');
DatabaseProvider.SignInDatabase(usersDatabase);

usersDatabase.AddUser(user1);
usersDatabase.AddUser(user2);

let product1 = new ProductEntity();
product1.name = "Кофта H&M";
product1.type = "Одежда";
product1.subType = "Верхняя одежда";
product1.sex = "Женский";
product1.description = "Состав ткани: хлопок 59%, полиэстер 41%";
product1.brand = "H&M";
product1.price = 2900;
product1.imagePath = "assets/images/products/1.webp";

let product2 = new ProductEntity();
product2.name = "Сумка Guess";
product2.type = "Аксессуары";
product2.subType = "Сумки";
product2.sex = "Женский";
product2.description = "Сумка выполнена из искусственной кожи. Детали: откидной клапан с магнитами, одно отделение, 3 внутренних кармана, текстильная подкладка.";
product2.brand = "Guess";
product2.price = 15399;
product2.imagePath = "assets/images/products/2.webp";

let product3 = new ProductEntity();
product3.name = "Духи Boss 100мл";
product3.type = "Косметика";
product3.subType = "Духи";
product3.sex = "Мужской";
product3.description = "Чувственный, древесный, теплый и свежий аромат Boss №6 for men создан для современного мужчины 21 столетия.";
product3.brand = "HUGO BOSS";
product3.price = 9900;
product3.imagePath = "assets/images/products/3.jpg";

let product4 = new ProductEntity();
product4.name = "Пуховик Befree";
product4.type = "Одежда";
product4.subType = "Верхняя одежда";
product4.sex = "Женский";
product4.description = "Длинная стеганая куртка-пальто свободного кроя oversize из плотной ветроотталкивающей ткани с натуральным утеплителем пух/перо (70/30)";
product4.brand = "Befree";
product4.price = 12467;
product4.imagePath = "assets/images/products/4.png";

let product5 = new ProductEntity();
product5.name = "Куртка GJ";
product5.type = "Одежда";
product5.subType = "Верхняя одежда";
product5.sex = "Женский";
product5.description = "Детали: силуэт oversize, капюшон, спущенная линия плеч, манжеты, застёжка на молнию, карманы.";
product5.brand = "Gloria Jeans";
product5.price = 1407;
product5.imagePath = "assets/images/products/5.jpg";

let product6 = new ProductEntity();
product6.name = "Футболка черная";
product6.type = "Одежда";
product6.subType = "Верхняя одежда";
product6.sex = "Женский";
product6.description = "Модель из плотного спортивного трикотажа приятна к телу и не требует специального ухода.";
product6.brand = "Gloria Jeans";
product6.price = 1407;
product6.imagePath = "assets/images/products/6.jpg";

let product7 = new ProductEntity();
product7.name = "Худи Eazyway";
product7.type = "Одежда";
product7.subType = "Верхняя одежда";
product7.sex = "Женский";
product7.description = "Женский оверсайз худи объемной формы из футера 3 нитка с начесом. Худи с перепадом длины , уходящим к спинке, обьемным капюшоном.";
product7.brand = "Eazyway";
product7.price = 4148;
product7.imagePath = "assets/images/products/7.jpg";

let product8 = new ProductEntity();
product8.name = "\"Black Vanilla\"";
product8.type = "Косметика";
product8.subType = "Духи";
product8.sex = "Женский";
product8.description = "белые сорта табака, ваниль, амбра";
product8.brand = "Dilis Parfum";
product8.price = 945;
product8.imagePath = "assets/images/products/8.jpg";

let product9 = new ProductEntity();
product9.name = "Dior Помада ";
product9.type = "Косметика";
product9.subType = "Помада";
product9.sex = "Женский";
product9.description = "#100 Nude Look";
product9.brand = "Dior";
product9.price = 6537;
product9.imagePath = "assets/images/products/9.jpg";

let product10 = new ProductEntity();
product10.name = "Dior Тональная эмульсия";
product10.type = "Косметика";
product10.subType = "Тон";
product10.sex = "Женский";
product10.description = "Откройте для себя натуральный финиш тонального средства Dior Forever Natural Nude: 24ч идеальное натуральное покрытие, формула состоящая из 96% натуральных ингредиентов- концентрация цветочного ухода за кожей.";
product10.brand = "Dior";
product10.price = 12780;
product10.imagePath = "assets/images/products/10.jpg";

let product11 = new ProductEntity();
product11.name = "Bioderma - мусс";
product11.type = "Косметика";
product11.subType = "Очищение";
product11.sex = "Женский";
product11.description = "\"Sebium\" (помпа) 200 мл";
product11.brand = "Bioderma";
product11.price = 1488;
product11.imagePath = "assets/images/products/11.jpg";

let product12 = new ProductEntity();
product12.name = "Помада VELVET";
product12.type = "Косметика";
product12.subType = "Помада";
product12.sex = "Женский";
product12.description = "PERIPERA INK AIRY VELVET жидкая тон 24 heavenly peach";
product12.brand = "PERIPERA INK AIRY VELVET";
product12.price = 587;
product12.imagePath = "assets/images/products/12.jpg";

let product13 = new ProductEntity();
product13.name = "Dyson";
product13.type = "Техника";
product13.subType = "Фен";
product13.sex = "Женский";
product13.description = "Фен-стайлер Dyson Airwrap complete long HS05 EU, bright nickel/bright copper";
product13.brand = "Dyson";
product13.price = 67458;
product13.imagePath = "assets/images/products/13.jpg";

let product14 = new ProductEntity();
product14.name = "Фен дорожный";
product14.type = "Техника";
product14.subType = "Фен";
product14.sex = "Женский";
product14.description = "Scarlett SC-HD70T28, 1000 Вт, складная ручка, 2 скорости, 1 температурный режим, 1 насадка";
product14.brand = "Scarlett";
product14.price = 67458;
product14.imagePath = "assets/images/products/14.jpg";

let product15 = new ProductEntity();
product15.name = "iPhone 13";
product15.type = "Техника";
product15.subType = "Смартфон";
product15.sex = "Женский";
product15.description = "Смартфон Apple iPhone 13 128 ГБ, nano SIM+eSIM, тёмная ночь";
product15.brand = "Apple";
product15.price = 66132;
product15.imagePath = "assets/images/products/15.jpg";

let product16 = new ProductEntity();
product16.name = "Samsung Galaxy S22 Ultra";
product16.type = "Техника";
product16.subType = "Смартфон";
product16.sex = "Женский";
product16.description = "Смартфон Samsung Galaxy S22 Ultra 8/128 ГБ, Dual: nano SIM + eSIM, черный фантом";
product16.brand = "Samsung";
product16.price = 79822;
product16.imagePath = "assets/images/products/16.jpg";

let product17 = new ProductEntity();
product17.name = "HONOR 90";
product17.type = "Техника";
product17.subType = "Смартфон";
product17.sex = "Женский";
product17.description = "HONOR 90 256GB Полночный черный";
product17.brand = "HONOR";
product17.price = 32957;
product17.imagePath = "assets/images/products/17.jpg";

let product18 = new ProductEntity();
product18.name = "Сумка-багет";
product18.type = "Аксессуары";
product18.subType = "Сумки";
product18.sex = "Женский";
product18.description = "23х14х7, сумка на плечо имеет одно отделение на молнии, и два кармана наружных, на молнии сзади и спереди на магните.";
product18.brand = "China";
product18.price = 736;
product18.imagePath = "assets/images/products/18.jpg";

let product19 = new ProductEntity();
product19.name = "Сумка кросс-боди";
product19.type = "Аксессуары";
product19.subType = "Сумки";
product19.sex = "Женский";
product19.description = "Сумка женская кросс боди идеально подойдет для хранения самых необходимых вещей: кошелька, телефона, ключей и косметики. Вы также можете хранить в ней личные мелочи, такие как карточки, документы или зарядные устройства. Сумка из натуральной кожи женская придаст вашему образу особый шарм и элегантность.";
product19.brand = "Beautiful Birds Finch";
product19.price = 10071;
product19.imagePath = "assets/images/products/19.jpg";

let product20 = new ProductEntity();
product20.name = "Серьги";
product20.type = "Аксессуары";
product20.subType = "Серьги";
product20.sex = "Женский";
product20.description = "Необычные серебряные серьги придутся по вкусу любителям животных. Сережки изготовлены из серебра 925 пробы и окрытого родием, что обеспечивает долговременное ношение без потери привлекательности.";
product20.brand = "Russia";
product20.price = 1125;
product20.imagePath = "assets/images/products/20.jpg";

let product21 = new ProductEntity();
product21.name = "Серьги The Jeweller";
product21.type = "Аксессуары";
product21.subType = "Серьги";
product21.sex = "Женский";
product21.description = "Ювелирные серьги из серебра. Серебряные сережки весом: 4.97 грамм 925 пробы. Вставка: жемчуг натуральный. Родиевое покрытие.";
product21.brand = "Russia";
product21.price = 3374;
product21.imagePath = "assets/images/products/21.jpg";

let product22 = new ProductEntity();
product22.name = "Футболка DH";
product22.type = "Одежда";
product22.subType = "Футболка";
product22.sex = "Мужской";
product22.description = "Футболки Design Heroes изготовлены из 100% хлопка кольцевого прядения и соответствуют международным и внутренним стандартам качества.";
product22.brand = "Design Heroes";
product22.price = 1215;
product22.imagePath = "assets/images/products/22.jpg";

let product23 = new ProductEntity();
product23.name = "Футболка DH";
product23.type = "Одежда";
product23.subType = "Футболка";
product23.sex = "Мужской";
product23.description = "Высококачественная гребенная пряжа пенье обеспечивает исключительный комфорт при носке, а изображение устойчиво к многократным стиркам, не мнется, не растрескивается и, действительно, не ощущается на ткани.";
product23.brand = "Design Heroes";
product23.price = 1432;
product23.imagePath = "assets/images/products/23.jpg";

let product24 = new ProductEntity();
product24.name = "Худи IVDT37";
product24.type = "Одежда";
product24.subType = "Худи";
product24.sex = "Мужской";
product24.description = "Это идеальная толстовка для мужчин, которые ценят комфорт и стиль в одежде. Толстовка выполнена в стильном oversize-силуэте, который позволяет подчеркнуть твою индивидуальность и придать образу небрежный шарм.";
product24.brand = "IVDT37";
product24.price = 2585;
product24.imagePath = "assets/images/products/24.jpg";

let product25 = new ProductEntity();
product25.name = "Рубашка Befree";
product25.type = "Одежда";
product25.subType = "Рубашка";
product25.sex = "Мужской";
product25.description = "Рубашка oversize фланелевая с принтом в клетку. Удлиненная мужская рубашка свободного кроя oversize из плотной, мягкой фланелевой ткани.";
product25.brand = "Befree";
product25.price = 3317;
product25.imagePath = "assets/images/products/25.jpg";

let product26 = new ProductEntity();
product26.name = "Брюки";
product26.type = "Одежда";
product26.subType = "Брюки";
product26.sex = "Мужской";
product26.description = "Черные брюки с принтом — это стильные оверсайз штаны с принтом маски. В этих широких, спортивных trap брюках вы заметно выделитесь из толпы — они подойдут, как для уличной прогулки, так и для вечеринки с друзьями и простого прибывания дома.";
product26.brand = "China";
product26.price = 1971;
product26.imagePath = "assets/images/products/26.jpg";

let product30 = new ProductEntity();
product30.name = "Увлажняющий крем";
product30.type = "Косметика";
product30.subType = "Крем";
product30.sex = "Мужской";
product30.description = "Крем для лица увлажнение и уход 3 в 1, мужской, для любого типа кожи. Увлажняющая и питающая кожу формула обеспечивает комфортом на весь день.";
product30.brand = "HERO'S";
product30.price = 850;
product30.imagePath = "assets/images/products/30.jpg";

let product27 = new ProductEntity();
product27.name = "Многофункциональное средство";
product27.type = "Косметика";
product27.subType = "Крем";
product27.sex = "Мужской";
product27.description = "Увлажняющее средство 3 в 1: тоник, сыворотка и лосьон. Питает и увлажняет сухую кожу. Всего 1 минута - и Ваша кожа увлажнена и насыщена кислородом для предотвращения дальнейшей сухости и стянутости, как после бритья, так и после ежедневного умывания.";
product27.brand = "The Skin House";
product27.price = 1785;
product27.imagePath = "assets/images/products/27.jpg";

let product28 = new ProductEntity();
product28.name = "Yohji Yamamoto т/в";
product28.type = "Косметика";
product28.subType = "Духи";
product28.sex = "Мужской";
product28.description = "Выдержанный и благородный аромат, созданный в лучших традициях всемирно известного японского бренда. Пирамида аромата раскрывается верхними нотами острого черного перца с присущей ему пикантностью и зажигательностью.";
product28.brand = "Yohji Yamamoto";
product28.price = 2600;
product28.imagePath = "assets/images/products/28.jpg";

let product29 = new ProductEntity();
product29.name = "Очищающая пенка";
product29.type = "Косметика";
product29.subType = "Пенка";
product29.sex = "Мужской";
product29.description = "Нежная пенка, специально разработанная для ежедневного очищения мужской кожи. Очищающая пенка контролирует излишнее выделение себума кожей, удаляет загрязнения, образуя густую пышную пену.";
product29.brand = "The Skin House";
product29.price = 1400;
product29.imagePath = "assets/images/products/29.jpg";

let product31 = new ProductEntity();
product31.name = "iPhone 13";
product31.type = "Техника";
product31.subType = "Смартфон";
product31.sex = "Мужской";
product31.description = "Смартфон Apple iPhone 13 128 ГБ, nano SIM+eSIM, тёмная ночь";
product31.brand = "Apple";
product31.price = 66132;
product31.imagePath = "assets/images/products/15.jpg";

let product32 = new ProductEntity();
product32.name = "Samsung Galaxy S22 Ultra";
product32.type = "Техника";
product32.subType = "Смартфон";
product32.sex = "Мужской";
product32.description = "Смартфон Samsung Galaxy S22 Ultra 8/128 ГБ, Dual: nano SIM + eSIM, черный фантом";
product32.brand = "Samsung";
product32.price = 79822;
product32.imagePath = "assets/images/products/16.jpg";

let product33 = new ProductEntity();
product33.name = "HONOR 90";
product33.type = "Техника";
product33.subType = "Смартфон";
product33.sex = "Мужской";
product33.description = "HONOR 90 256GB Полночный черный";
product33.brand = "HONOR";
product33.price = 32957;
product33.imagePath = "assets/images/products/17.jpg";

let product34 = new ProductEntity();
product34.name = "Xiaomi RedmiBook 15";
product34.type = "Техника";
product34.subType = "Ноутбук";
product34.sex = "Мужской";
product34.description = "15.6 Ноутбук Xiaomi RedmiBook 15 1920x1080, Intel Core i3 1115G4 3 ГГц, RAM 8 ГБ, DDR4, SSD 256 ГБ, Intel UHD Graphics, Windows 11 Home, JYU4525RU, серый";
product34.brand = "Xiaomi";
product34.price = 35957;
product34.imagePath = "assets/images/products/34.jpg";

let product35 = new ProductEntity();
product35.name = "Электрическая бритва Polaris";
product35.type = "Техника";
product35.subType = "Бритва";
product35.sex = "Мужской";
product35.description = "Электрическая бритва Polaris PMR 0411RC ProLong 4D Li+ POLARIS";
product35.brand = "Polaris";
product35.price = 2058;
product35.imagePath = "assets/images/products/35.jpg";

let product36 = new ProductEntity();
product36.name = "Рюкзак кожаный";
product36.type = "Аксессуары";
product36.subType = "Сумка";
product36.sex = "Мужской";
product36.description = "Стильный рюкзак подходит для мужчин и женщин и будет отличным дополнением к любому гардеробу. Изготовлен из искусственной кожи, которая выглядит и ощущается как натуральная.";
product36.brand = "China";
product36.price = 1432;
product36.imagePath = "assets/images/products/36.jpg";

let product37 = new ProductEntity();
product37.name = "Сумка didas";
product37.type = "Аксессуары";
product37.subType = "Сумка";
product37.sex = "Мужской";
product37.description = "Уникальная сумка adidas originals - идеальный аксессуар для активных и стильных мужчин и женщин.";
product37.brand = "Adidas";
product37.price = 2210;
product37.imagePath = "assets/images/products/37.jpg";

let product38 = new ProductEntity();
product38.name = "Наручные часы CASIO";
product38.type = "Аксессуары";
product38.subType = "Часы";
product38.sex = "Мужской";
product38.description = "Наручные часы CASIO Vintage Наручные часы Casio A-159W-N1D, серебряный.";
product38.brand = "CASIO";
product38.price = 1998;
product38.imagePath = "assets/images/products/38.jpg";

let product39 = new ProductEntity();
product39.name = "Кошелек";
product39.type = "Аксессуары";
product39.subType = "Кошелек";
product39.sex = "Мужской";
product39.description = "Самый компактный кошелек в мире с большими возможностями! Полностью выполнен вручную, от раскроя до обработки краев каждой детали.";
product39.brand = "China";
product39.price = 998;
product39.imagePath = "assets/images/products/39.jpg";

let product40 = new ProductEntity();
product40.name = "Ремень черный";
product40.type = "Аксессуары";
product40.subType = "Ремень";
product40.sex = "Мужской";
product40.description = "Ремень Kijua с люверсами, ремень с кольцами, черный.";
product40.brand = "Kijua";
product40.price = 305;
product40.imagePath = "assets/images/products/40.jpg";

var productsDatabase = new ProductsDatabase('ProductsDatabase');
DatabaseProvider.SignInDatabase(productsDatabase);

function fillDatabase() {

    productsDatabase.UpdateItem(product1);
    productsDatabase.UpdateItem(product2);
    productsDatabase.UpdateItem(product3);
    productsDatabase.UpdateItem(product4);
    productsDatabase.UpdateItem(product5);
    productsDatabase.UpdateItem(product6);
    productsDatabase.UpdateItem(product7);
    productsDatabase.UpdateItem(product8);
    productsDatabase.UpdateItem(product9);
    productsDatabase.UpdateItem(product10);
    productsDatabase.UpdateItem(product11);
    productsDatabase.UpdateItem(product12);
    productsDatabase.UpdateItem(product13);
    productsDatabase.UpdateItem(product14);
    productsDatabase.UpdateItem(product15);
    productsDatabase.UpdateItem(product16);
    productsDatabase.UpdateItem(product17);
    productsDatabase.UpdateItem(product18);
    productsDatabase.UpdateItem(product19);
    productsDatabase.UpdateItem(product20);
    productsDatabase.UpdateItem(product21);
    productsDatabase.UpdateItem(product22);
    productsDatabase.UpdateItem(product23);
    productsDatabase.UpdateItem(product24);
    productsDatabase.UpdateItem(product25);
    productsDatabase.UpdateItem(product26);
    productsDatabase.UpdateItem(product27);
    productsDatabase.UpdateItem(product28);
    productsDatabase.UpdateItem(product29);
    productsDatabase.UpdateItem(product30);
    productsDatabase.UpdateItem(product31);
    productsDatabase.UpdateItem(product32);
    productsDatabase.UpdateItem(product33);
    productsDatabase.UpdateItem(product34);
    productsDatabase.UpdateItem(product35);
    productsDatabase.UpdateItem(product36);
    productsDatabase.UpdateItem(product37);
    productsDatabase.UpdateItem(product38);
    productsDatabase.UpdateItem(product39);
    productsDatabase.UpdateItem(product40);

}
//fillDatabase();

var cartItemsDatabase = new CartItemsDatabase('CartItemsDatabase');
DatabaseProvider.SignInDatabase(cartItemsDatabase);

if (Authentication.GetCurrentUser() !== null) {
    let profileHeaderLink = document.getElementById('profile-header-link');
    profileHeaderLink.onclick = () => window.location.href = 'profile.html';
    profileHeaderLink.style.cursor = 'pointer';
    profileHeaderLink.innerText = Authentication.GetCurrentUser().login;
}