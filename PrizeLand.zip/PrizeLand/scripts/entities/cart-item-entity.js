class CartItemEntity extends DatabaseEntity{
    productId;
    userId;
}