class UserEntity extends DatabaseEntity{
    login;
    password;


    SetLogin(login){
        let loginRegex = /^(?=.*[a-z])(?=.*[A-Z]).{3,20}$/;
        if(login.match(loginRegex))
        {
            this.login = login;
            return true;
        }
        else {
            return false;
        }
    }
    SetPassword(password){
        let passwordRegex = /[0-9a-zA-Z]{6,}/g;
        if(password.match(passwordRegex))
        {
            this.password = password;
            return true;
        }
        else {
            return false;
        }
    }
}
class UserInfo{
    city;
    username;
    phone;
}