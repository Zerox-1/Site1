class ProductEntity extends DatabaseEntity{
    name;
    description;
    type;
    subType;
    brand;
    sex;
    price;
    imagePath;
}