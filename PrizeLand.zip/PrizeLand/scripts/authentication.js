class Authentication{
    static SignIn(login, password){
        let founded = usersDatabase.data.find((user) => user.login === login);

        if(founded === undefined){
            return false;
        }

        if(founded.password !== password){
            return false;
        }

        this.SetCurrentUser(founded);
        return true;
    }

    static SignUp(userEntity){
        if(!(userEntity instanceof UserEntity)){
            console.error('Given object is not instance of UserEntity class')
            return false;
        }

        return usersDatabase.AddUser(userEntity);
    }
    static LogOut(){
        localStorage.setItem('currentUser', null);
    }
    static GetCurrentUser(){
        return JSON.parse(localStorage.getItem('currentUser'));
    }
    static SetCurrentUser(userEntity){
        // if(!(userEntity instanceof UserEntity)){
        //     console.error('Given object is not instance of UserEntity class')
        //     return false;
        // }

        localStorage.setItem('currentUser', JSON.stringify(userEntity));
        return true;
    }
}