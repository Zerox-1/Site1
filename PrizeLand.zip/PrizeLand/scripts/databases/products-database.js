class ProductsDatabase extends Database{

}