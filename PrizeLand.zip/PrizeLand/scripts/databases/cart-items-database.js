class CartItemsDatabase extends Database{

}