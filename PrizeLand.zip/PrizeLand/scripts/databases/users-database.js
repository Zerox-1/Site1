class UsersDatabase extends Database{

    AddUser(userEntity){
        if(!(userEntity instanceof UserEntity)){
            console.error('Given object is not instance of UserEntity class')
            return false;
        }

        let founded = this.data.find((user) => user.login === userEntity.login);
        if(founded !== undefined){
            console.error('Given object is already in database');
            return false;
        }

        this.UpdateItem(userEntity);
        return true;
    }
    UpdateUser(userEntity){
        this.UpdateItem(userEntity);
        return true;
    }
}