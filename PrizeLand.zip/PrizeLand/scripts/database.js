class Database{
    databaseName;
    data;
    constructor(databaseName, data = []) {
        this.databaseName = databaseName;
        this.data = data;
    }
    UpdateItem(item){
        let founded = this.GetById(parseInt(item.id));

        if(founded === undefined){
            let maxId = 0;
            if(this.data.length !== 0){
                this.data.forEach(el =>{
                    if(el.id > maxId){
                        maxId = el.id;
                    }
                })
            }

            item.id = maxId + 1;
            this.data.push(item);
        }
        else {
            this.data[this.data.indexOf(founded)] = item;
        }

        DatabaseProvider.UpdateDatabase(this);
    }
    RemoveItem(item){
        let founded = this.GetById(item.id);
        let itemIndex = this.data.indexOf(founded);

        if(itemIndex !== -1){
            this.data.splice(itemIndex, itemIndex);
            console.log(this.data);
        }
        if(itemIndex === 0 && this.data.length === 1){
            this.data = [];
        }

        DatabaseProvider.UpdateDatabase(this);
    }
    GetById(id){
        return this.data.find((element) => element.id === id)
    }

    static GetById(data, id){
        return data.find((element) => element.id === id)
    }
}
class DatabaseProvider{
    static SignedDatabases = [];
    static UpdateDatabase(database){
        localStorage.setItem(database.databaseName, JSON.stringify(database));
    }

    static SignInDatabase(database){
        let db = JSON.parse(localStorage.getItem(database.databaseName));
        if(db != null){
            db.data.forEach(el =>{
                if(!database.data.includes(el)){
                    database.data.push(el);
                }
            })
        }
        DatabaseProvider.SignedDatabases.push(database);
    }
}