class DatabaseEntity {
    id;
}